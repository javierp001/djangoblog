<template>
    <!-- TOP DESTINATION SECTION -->
    <section class="topDestinationSection"  v-if="sitios.length>0">
        <div style="margin-left:30px; margin-right:30px;">
            <div class="sectionTitleHomeCity">
                <h2>{{title}}</h2>
                <p>{{subtitle}}</p>
            </div>
            <div :id="`carousel-${idCarousel}`">
                <div class="isotopeSelector" v-for="sitio in sitios" :key="'dest-'+sitio.id"
                     style="margin-left: 20px">
                    <figure>
                        <img :src="`/uploads/${sitio.fotos[0].imagen}`"
                             alt="" v-if="sitio.fotos.length>0" class="own_adjust-img-top">
                        <img :src="`/uploads/fotos/default.png`" alt="" v-else class="own_adjust-img-top">
                        <h4>{{sitio.nombre}}</h4>
                        <div class="overlay-background">
                            <div class="inner"></div>
                        </div>
                        <div class="overlay">
                            <a class="fancybox-pop"
                               :href="`/publico/sitio/${sitio.id}`">
                                        <!--<span class="overlayInfo">
                                            <h5>Visitar</h5>
                                            <p><i class="fa fa-arrow-circle-right fa-2x" aria-hidden="true"></i></p>
                                        </span>-->
                            </a>
                        </div>
                    </figure>
                </div>
                <!--<div id="carousel">
                    <div v-for="sitio in sitios" :key="'dest-'+sitio.id">
                        <a :href="`/publico/sitio/${sitio.id}`">
                            <img :src="`/uploads/${sitio.fotos[0].imagen}`"
                                 alt="" v-if="sitio.fotos.length>0" class="own_adjust-img-top">
                            <img :src="`/uploads/fotos/default.png`" alt="" v-else class="own_adjust-img-top">
                        </a>
                    </div>
                </div>-->
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name: "PublicDestacadosCarousel",
        props: {
            idCarousel:String,
            sitios: Array,
            title:String,
            subtitle:String
        },
        mounted() {
            $(`#carousel-${this.idCarousel}`).slick({
                infinite: true,
                slidesToShow: this.sitios.length>=3?3:this.sitios.length,
                //arrows: true,
                dots:true,
                autoplay: true,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: this.sitios.length>=3?3:this.sitios.length,
                            slidesToScroll: this.sitios.length>=3?3:this.sitios.length,
                            infinite: true,
                            dots: true
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: this.sitios.length>=2?2:this.sitios.length,
                            slidesToScroll: this.sitios.length>=2?2:this.sitios.length
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                    // You can unslick at a given breakpoint now by adding:
                    // settings: "unslick"
                    // instead of a settings object
                ]
            });
            console.log(this.sitios);
        }
    }
</script>

<style scoped>

    .container-slick-slider {

    }
</style>

<style>
    .slick-prev:before, .slick-next:before {
        color: #000;
    }

    .own_adjust-img-top {
        /*width: 100%;*/
        /*height: 500px;*/
        max-height: 377px;
        object-fit: cover;
    }
</style>