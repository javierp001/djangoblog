
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require('./bootstrap');

window.Vue = require('vue');

import VueRouter from 'vue-router'
Vue.use(VueRouter)

import {ClientTable, Event, ServerTable} from 'vue-tables-2';
Vue.use(ClientTable);
Vue.use(ServerTable);


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

Vue.component('provincias',require('./components/Provincias'));
Vue.component('cantones',require('./components/Cantones'));
Vue.component('categorias',require('./components/Categorias'));
Vue.component('categoria-tipos',require('./components/CategoriaTipos'));
Vue.component('propietarios',require('./components/Propietarios'));
Vue.component('sitios',require('./components/Sitios'));
Vue.component('historias',require('./components/Historias'));
Vue.component('rutas',require('./components/Rutas'));
Vue.component('areas',require('./components/Areas'));
Vue.component('link-confirmacion-modal',require('./components/LinkConfirmacionModal'));
Vue.component('fotos',require('./components/Fotos'));
Vue.component('eventos',require('./components/Eventos'));
Vue.component('servicios',require('./components/Servicios'));
Vue.component('users',require('./components/Users'));
Vue.component('visitas',require('./components/Visitas'));
Vue.component('opiniones',require('./components/Opiniones'));
Vue.component('mensajes-contacto',require('./components/MensajesContacto'));
Vue.component('modal-show-informacion',require('./components/ModalShowInformacion'));

Vue.component('public-header-navbar', require('./components/publico/PublicHeaderNavbar'));
Vue.component('public-sitios-canton',require('./components/publico/PublicSitiosCanton'));
Vue.component('public-sitio',require('./components/publico/PublicSitio'));
Vue.component('public-sitios-mapa',require('./components/publico/PublicSitiosMapa'));
Vue.component('public-sitios',require('./components/publico/PublicSitios'));
Vue.component('public-index-search-bar',require('./components/publico/PublicIndexSearchBar'));
Vue.component('public-sitio-opiniones',require('./components/publico/PublicSitioOpiniones'));
Vue.component('public-sitios-rating',require('./components/publico/PublicSitiosRating'));
Vue.component('PublicDestacadosCarousel',require('./components/publico/PublicDestacadosCarousel'));

Vue.component('example',require('./components/publico/Example'));

const app = new Vue({
    el: '#app'
});
